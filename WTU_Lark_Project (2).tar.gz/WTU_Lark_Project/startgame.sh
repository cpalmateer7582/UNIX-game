#!/bin/bash

#Defining Variables
WTU_pathToPlayerData="PlayerData"
WTU_Name=""
WTU_inGame="False"
WTU_playerMilestone="0"
WTU_playerRank="5"

#Used to make a typewriter effect.
typeWriter() {
	for ((index = 0; index <=${#1}; index++)); do
		if [[ "${1:$index:1}i" != *\\* ]]
		then
			printf '%s' "${1:$index:1}"
			sleep 0.1
		else
			if [[ "${1:$index+1:1}" = 'n' ]]
			then
				echo
				index=$((index+1))
			fi
		fi
	done
}

#Lower the players rank.
lowerRank() {
	if [[ "$WTU_playerRank" -gt "1" ]] 
	then
		WTU_playerRank=$(($WTU_playerRank - 1))
	fi
}

#Check for help
while test $# -gt 0; do
	case "$1" in
		-h|--help)
			typeWriter "This is the starting script for the game.\nIt can also be used to end the game early.\n"
			exit 0
			;;
	esac
done

#Check if player data exists, and if so, loads it.
if [[ -f $WTU_pathToPlayerData ]]
then
	WTU_Name=$(awk 'NR==1' $WTU_pathToPlayerData)
	WTU_inGame=$(awk 'NR==2' $WTU_pathToPlayerData)
	WTU_playerMilestone=$(awk 'NR==3' $WTU_pathToPlayerData)
	WTU_playerRank=$(awk 'NR==4' $WTU_pathToPlayerData)
fi

#Check if player is in game. Case exists if Player Data gets changed.
if [[ $WTU_inGame == "False" || $WTU_inGame != "True" ]] 
then
	clear
	typeWriter "Welcome to U*&^@x!\n" 
	typeWriter "Please log in:\n"
	typeWriter "Name: "
	read WTU_Name
	typeWriter "Hello, $WTU_Name, thank you for logging in.\nYou have 1 notification.\nA virus has been detected.\n"
	sleep 0.5
	echo 'ERROR'
	sleep 0.5
	echo 'ERROR'
	sleep 0.5
	echo 'ERROR'
	sleep 0.5
	typeWriter "System abnormalities detected.\nINITIATE TERMINATION PROCESS.\nPLEASE SEE 'logs/guide.log'.\n"
	typeWriter "To access logs/, use the Change Directory command: cd [directory].\nFor example, 'cd logs/'.\n"
	typeWriter "To see what files exist in a directory, use the List command: ls.\nTo view the log, use the Concatenate command: cat [file]\nFor example, 'cat guide.log'.\n"
	WTU_inGame="True"
	tar -xzf .GAME
	WTU_playerMilestone="1"
else
	if [[ $WTU_inGame == "True" ]]
	then
		if [[ "$WTU_playerMilestone" -lt "12" ]]
		then
			typeWriter "$WTU_Name, you are already in game.\nYou have reached milestone $WTU_playerMilestone of 12.\nWould you like to end the game? (Y/n): "
			read userResponse
			if [[ ${userResponse,,} == "y" ]]
			then
				typeWriter "The game has ended. Goodbye, $WTU_Name.\n"
				rm -r elimination/
				rm -r logs/
				WTU_Name=""
				WTU_inGame="False"
				WTU_playerMilestone="0"
				WTU_playerRank="5"
			else 
				if [[ ${userResponse,,} == "n" ]] #Curly braces + two commas to make it case insensitive
				then
					typeWriter "The game shall continue.\n"
				else
					typeWriter "Please try again.\n"
				fi
			fi
		else
			typeWriter "$WTU_Name, congratulations. You have defeated DIVOC-19.\nThe game is coming to an end.\n"
			typeWriter "Virus removed from all essential files. Opening final message.\n"
			if [[ "$WTU_playerRank" -ge "5" ]] 
			then
				typeWriter "CURSE YOU ${WTU_Name^^}. HOW COULD YOU DEFEAT ME? I WAS CREATED TO DESTROY ALL.\nSO WHY? WHY HAS A MERE BEGI-\n"
				typeWriter "System stability: 100%.\nDIVOC-19 has been eradicated.\n"
				typeWriter "As a gift, I will tell you about 'apropos', a command you can use to search for commands.\n"
				typeWriter "Using 'apropos [word]' will search for commands that have that word in their manual files.\n"
				typeWriter "You can use it as a way to find a command you can describe but do not know the name of.\n"
			else
				typeWriter "${WTU_Name^^}. YOU HAVE PREVENTED ME FROM SPREADING.\n"
				if [[ "$WTU_playerRank" -ge "2" ]]
				then
					typeWriter "YOU HAVE EVEN STOPPED ME FROM TAKING OVER YOUR SYSTEM.\n"
					typeWriter "BUT KNOW THIS ${WTU_Name^^}, I WILL BE BACK.\nI WAS CREATED TO DESTROY ALL, NO MATTER HOW LONG IT TAKES.\n"
					typeWriter "YOU ARE SAFE FOR NOW. I WILL RETURN WHEN YOU LEAST EXPECT IT.\nKEEP YOUR SKILLS SHARP FOR THAT DAY.\n"
					typeWriter "System stabilitiy: 99%.\nDIVOC-19 has been removed.\n"
				else
					typeWriter "HOWEVER, HUMAN, YOU HAVE NOT STOPPED ME FROM DESTROYING YOUR SYSTEM.\nSAY GOODBYE, ${WTU_Name^^}, FOR I AM TAKING YOUR SYSTEM DOWN WITH ME.\n"
					sleep 0.5
					echo 'ERROR'
					sleep 0.5
					echo 'ERROR'
					sleep 0.5
					echo 'ERROR'
					sleep 0.5
					typeWriter "File system deleted.\n" 
				fi
			fi
			rm -r elimination/
			rm -r logs/
			WTU_Name=""
			WTU_inGame="False"
			WTU_playerMilestone="0"
			WTU_playerRank="5"
		fi	
	fi
fi

echo "$WTU_Name" > $WTU_pathToPlayerData
echo "$WTU_inGame" >> $WTU_pathToPlayerData
echo "$WTU_playerMilestone" >> $WTU_pathToPlayerData
echo "$WTU_playerRank" >> $WTU_pathToPlayerData
